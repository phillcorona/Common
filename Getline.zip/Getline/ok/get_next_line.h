/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.h                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcorona- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/19 11:22:30 by fcorona-          #+#    #+#             */
/*   Updated: 2024/11/25 15:11:15 by fcorona-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef GET_NEXT_LINE_H
# define GET_NEXT_LINE_H

# include <unistd.h> // Para utilizar o read
# include <stdlib.h> // para utilizar o malloc
# include <fcntl.h> // Para utilizar o open

# ifndef BUFFER_SIZE
#  define BUFFER_SIZE 1069
# endif

size_t	ft_strlen(const char *str);
//char	*ft_strdup(const char *str, size_t n);
void	*ft_memset(void *s, int c, size_t n);
void	*ft_calloc(size_t nmemb, size_t size);
char	*ft_strchr(const char *str, int c);
char	*ft_strjoin(const char *s1, const char *s2);

char	*get_next_line(int fd);

#endif

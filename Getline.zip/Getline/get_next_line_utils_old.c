/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_utils.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcorona- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/19 17:57:10 by fcorona-          #+#    #+#             */
/*   Updated: 2024/11/21 12:32:03 by fcorona-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

size_t	ft_strlen(const char *str)
{
	size_t	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

char	*ft_strdup(const char *str, size_t n)
{
	char	*dup;
	size_t	i;
	size_t	leng;

	i = 0;
	if (n == 0)
		leng = ft_strlen(str);
	else
		leng = n;
	dup = (char *)malloc((leng + 1) * sizeof(char));
	if (!dup)
		return (NULL);
	while (i < leng && str[i])
	{
		dup[i] = str[i];
		i++;
	}
	dup[i] = '\0';
	return (dup);
}

char	*ft_strchr(const char *str, int c)
{
	size_t	i;

	i = 0;
	while (str[i])
	{
		if (str[i] == (unsigned char)c)
			return ((char *)str + i);
		i++;
	}
	if (str[i] == (unsigned char) c)
		return ((char *)str + i);
	return (NULL);
}

char	*ft_strjoin(const char *s1, const char *s2)
{
	char	*result;
	int		i;
	int		j;

	i = 0;
	j = 0;
	if (s1 && s2)
	{
		result = (char *)malloc((ft_strlen(s1) + ft_strlen(s2) + 1)
				* sizeof(char));
		if (!result)
			return (NULL);
		while (s1[i])
			result[j++] = s1[i++];
		i = 0;
		while (s2[i])
			result[j++] = s2[i++];
		result[j] = '\0';
		return (result);
	}
	return (NULL);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcorona- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/21 12:52:49 by fcorona-          #+#    #+#             */
/*   Updated: 2024/11/21 17:34:24 by fcorona-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

char	*ft_join_free(char *s1, char *s2)
{
	char	*temp_buffer;

	temp_buffer = ft_strjoin(s1, s2);
	free(s1);
	return (temp_buffer);
}

char	*ft_fill_line(const char *buffer)
{
	char	*line;
	size_t	line_leng;
	size_t	i;

	line_leng = 0;
	while (buffer[line_leng] && buffer[line_leng] != '\n')
		line_leng++;
	if (buffer[line_leng] == '\n')
		line_leng++;
	line = (char *)malloc(line_leng + 1);
	if (!line)
		return (NULL);
	i = 0;
	while (i < line_leng)
	{
		line[i] = buffer[i];
		i++;
	}
	line[i] = '\0';
	return (line);
}

char	*ft_update_buffer(char *buffer, const char *line)
{
	size_t	buffer_leng;
	size_t	line_leng;
	size_t	i;
	char	*new_buffer;

	buffer_leng = ft_strlen(buffer);
	line_leng = ft_strlen(line);
	if (buffer_leng == line_leng)
		return (free(buffer), NULL);
	new_buffer = (char *)malloc(buffer_leng - line_leng + 1);
	if (!new_buffer)
		return (free(buffer), NULL);
	i = 0;
	while (buffer[line_leng + i])
	{
		new_buffer[i] = buffer[line_leng + i];
		i++;
	}
	new_buffer[i] = '\0';
	free(buffer);
	return (new_buffer);
}

char	*ft_fill_buffer(int fd, char *buffer)
{
	char	*tmp_buffer;
	size_t	bytes_read;

	if (!buffer)
		buffer = ft_calloc(1, 1);
	if (!buffer)
		return (NULL);
	tmp_buffer = (char *)malloc(BUFFER_SIZE + 1);
	if (!tmp_buffer)
	{
		free(buffer);
		return (NULL);
	}
	bytes_read = 1;
	while (bytes_read > 0)
	{
		bytes_read = read(fd, tmp_buffer, BUFFER_SIZE);
		if (bytes_read < 0)
			return (free(buffer), free(tmp_buffer), NULL);
		tmp_buffer[bytes_read] = '\0';
		buffer = ft_join_free(buffer, tmp_buffer);
		if (!buffer)
			return (free(tmp_buffer), NULL);
		if (ft_strchr(tmp_buffer, '\n'))
			break ;
	}
	return (free(tmp_buffer), buffer);
}

char	*get_next_line(int fd)
{
	static char	*static_buffer;
	char		*line;

	if (fd < 0 || BUFFER_SIZE <= 0)
		return (NULL);
	static_buffer = ft_fill_buffer(fd, static_buffer);
	if (!static_buffer)
		return (NULL);
	line = ft_fill_line(static_buffer);
	if (!line || !(line[0]))
	{
		free(static_buffer);
		static_buffer = NULL;
		return (free(line), NULL);
	}
	static_buffer = ft_update_buffer(static_buffer, line);
	return (line);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_num.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcorona- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/19 20:58:26 by fcorona-          #+#    #+#             */
/*   Updated: 2025/02/19 21:03:00 by fcorona-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"
#include "../lib/libft/includes/libft.h"

int	ft_check_dupl(int num, char **av, int i)
{
	i++;
	while (av[i])
	{
		if (ft_atoi(av[i]) == num)
		{
			return (1);
		}
		i++;
	}
	return (0);
}

char	**ft_sep_args(char *av)
{
	char	**arg;

	arg = ft_split(av, ' ');
	return (arg);
}

void	check_arg(int ac, char **av)
{
	int		i;
	long	tmp;
	char	**args;

	if (av[1][0] >= 'A' && av[1][0] <= 'z')
		ft_msg_error("Error");
	i = 1;
	if (ac == 2)
		args = ft_sep_args(av[1]);
	else
		args = av;
	while (args[i])
	{
		tmp = ft_atoi(args[i]);
		if (!ft_isnum(args[i]))
			ft_msg_error("Error");
		if (ft_check_dupl(tmp, args, i) == 1)
			ft_msg_error("Error");
		if (tmp < INT_MIN || tmp > INT_MAX)
			ft_msg_error("Error");
		i++;
	}
	if (ac == 2)
		free_args(args);
}

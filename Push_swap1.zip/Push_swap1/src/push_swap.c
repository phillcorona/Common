/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcorona- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/19 17:42:50 by fcorona-          #+#    #+#             */
/*   Updated: 2025/02/19 17:42:53 by fcorona-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

static void	start_stack(t_list **stack, int ac, char **av)
{
	t_list	*add_num;
	char	**args;
	int		i;

	i = 0;
	if (ac == 2)
		args = ft_split(av[1], ' ');
	else
	{
		i = 1;
		args = av;
	}
	while (args[i])
	{
		add_num = ft_lstnew(ft_atoi(args[i]));
		ft_lstadd_back(stack, add_num);
		i++;
	}
	id_stack(stack);
	if (ac == 2)
		free_args(args);
}

static void	sort_stack(t_list **stack_a, t_list **stack_b)
{
	if (ft_lstsize(*stack_a) <= 5)
		simple_sort(stack_a, stack_b);
	else
		radix_sort(stack_a, stack_b);
}

int	main(int ac, char **av)
{
	t_list	**stck_a;
	t_list	**stck_b;

	if (ac < 2)
		return (1);
	check_arg(ac, av);
	stck_a = malloc(sizeof(t_list));
	if (!stck_a)
		return (1);
	*stck_a = NULL;
	start_stack(stck_a, ac, av);
	if (check_sort(stck_a) == 1)
		exit(EXIT_SUCCESS);
	stck_b = malloc(sizeof(t_list));
	if (!stck_b)
	{
		free_stack(stck_a);
		return (1);
	}
	*stck_b = NULL;
	sort_stack(stck_a, stck_b);
	free_stack(stck_a);
	free_stack(stck_b);
	return (0);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcorona- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/24 10:53:13 by fcorona-          #+#    #+#             */
/*   Updated: 2025/02/24 11:25:11 by fcorona-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

int	push(t_list **stack_next, t_list **stack_back)
{
	t_list	*tmp;
	t_list	*head_next;
	t_list	*head_back;

	if (ft_lstsize(*stack_back) == 0)
		return (-1);
	head_next = *stack_next;
	head_back = *stack_back;
	tmp = head_back;
	head_back = head_back->next;
	*stack_back = head_back;
	if (!head_next)
	{
		head_next = tmp;
		head_next->next = NULL;
		*stack_next = head_next;
	}
	else
	{
		tmp->next = head_next;
		*stack_next = tmp;
	}
	return (0);
}

int	pa(t_list **stack_a, t_list **stack_b)
{
	if (push(stack_a, stack_b) == -1)
		return (-1);
	ft_printf("pa\n");
	return (0);
}

int	pb(t_list **stack_a, t_list **stack_b)
{
	if (push(stack_b, stack_a) == -1)
		return (-1);
	ft_printf("pb\n");
	return (0);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   error.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcorona- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/19 20:50:01 by fcorona-          #+#    #+#             */
/*   Updated: 2025/02/19 20:52:11 by fcorona-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"
//#include "../lib/libft/includes/ft_print.h"

void	ft_msg_error(char *str)
{
	ft_printf("%s\n", str);
	exit(EXIT_FAILURE);
}

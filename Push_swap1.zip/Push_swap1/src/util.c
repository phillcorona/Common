/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   util.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcorona- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/24 17:47:16 by fcorona-          #+#    #+#             */
/*   Updated: 2025/02/24 18:44:54 by fcorona-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

int	id_mov_head(t_list **stack, int id)
{
	t_list	*current;
	int		num_mov;

	num_mov = 0;
	current = *stack;
	while (current)
	{
		if (current->index == id)
			break ;
		num_mov++;
		current = current->next;
	}
	return (num_mov);
}

int	get_min_vl(t_list **stack, int value)
{
	t_list	*current;
	int		min_vl;

	current = *stack;
	min_vl = current->index;
	while (current->next)
	{
		current = current->next;
		if ((current->index < min_vl) && current->index != value)
			min_vl = current->index;
	}
	return (min_vl);
}

void	id_stack(t_list **stack)
{
	t_list	*current;
	t_list	*tmp;
	int		index;

	index = 0;
	while (index < ft_lstsize(*stack))
	{
		current = NULL;
		tmp = *stack;
		while (tmp)
		{
			if (tmp->index == -1 && (!current || tmp->value < current->value))
				current = tmp;
			tmp = tmp->next;
		}
		if (current)
			current->index = index++;
	}
}

int	check_sort(t_list **stack)
{
	t_list	*current;

	current = *stack;
	while (current && current->next)
	{
		if (current->value > current->next->value)
			return (0);
		current = current->next;
	}
	return (1);
}

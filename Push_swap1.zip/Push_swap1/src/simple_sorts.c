/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   simple_sorts.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcorona- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/24 16:24:46 by fcorona-          #+#    #+#             */
/*   Updated: 2025/02/24 17:04:32 by fcorona-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

void	sort_3(t_list **stack_a)
{
	t_list	*current;
	int		min_vl;
	int		prox_min;

	current = *stack_a;
	min_vl = get_min_vl(stack_a, -1);
	prox_min = get_min_vl(stack_a, min_vl);
	if (check_sort(stack_a) == 1)
		return ;
	if (current->index == min_vl && current->next->index != prox_min)
		sort_132(stack_a);
	else if (current->index == prox_min)
		sort_231(stack_a, current, min_vl);
	else
		sort_312(stack_a, current, min_vl);
}

void	sort_4(t_list **stack_a, t_list **stack_b)
{
	int	num_mov;

	if (check_sort(stack_a))
		return ;
	num_mov = id_mov_head(stack_a, get_min_vl(stack_a, -1));
	if (num_mov == 1)
		ra(stack_a);
	else if (num_mov == 2)
	{
		ra(stack_a);
		ra(stack_a);
	}
	else if (num_mov == 3)
		rra(stack_a);
	if (check_sort(stack_a))
		return ;
	pb(stack_a, stack_b);
	sort_3(stack_a);
	pa(stack_a, stack_b);
}

void	sort_5(t_list **stack_a, t_list **stack_b)
{
	int	num_mov;

	num_mov = id_mov_head(stack_a, get_min_vl(stack_a, -1));
	if (num_mov == 1)
		ra(stack_a);
	else if (num_mov == 2)
	{
		ra(stack_a);
		ra(stack_a);
	}
	else if (num_mov == 3)
	{
		rra(stack_a);
		rra(stack_a);
	}
	else if (num_mov == 4)
		rra(stack_a);
	if (check_sort(stack_a))
		return ;
	pb(stack_a, stack_b);
	sort_4(stack_a, stack_b);
	pa(stack_a, stack_b);
}

void	simple_sort(t_list **stack_a, t_list **stack_b)
{
	int	size;

	if (check_sort(stack_a) || ft_lstsize(*stack_a) == 0
		|| ft_lstsize(*stack_a) == 1)
		return ;
	size = ft_lstsize(*stack_a);
	if (size == 2)
		sa(stack_a);
	else if (size == 3)
		sort_3(stack_a);
	else if (size == 4)
		sort_4(stack_a, stack_b);
	else if (size == 5)
		sort_5(stack_a, stack_b);
}

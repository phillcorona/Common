/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcorona- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/17 19:18:37 by fcorona-          #+#    #+#             */
/*   Updated: 2025/02/17 19:25:45 by fcorona-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUSH_SWAP_H
# define PUSH_SWAP_H

# include "../lib/libft/includes/ft_printf.h"
# include "../lib/libft/includes/libft.h"
# include <limits.h>
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <unistd.h>
/*
typedef struct s_list
{
	int				value;
	int				index;
	struct s_list	*next;
}		t_list;*/

// Check Numbers
int					ft_check_dupl(int num, char **av, int i);
char				**ft_sep_args(char *av);
void				check_arg(int ac, char **av);
int					check_sort(t_list **stack);

// Error Message
void				ft_msg_error(char *str);

// Clean
void				free_stack(t_list **stack);
void				free_args(char **str);

// Revert Operations
int					rra(t_list **stack_a);
int					rrb(t_list **stack_b);
int					rrr(t_list **stack_a, t_list **stack_b);

// Rotate Operations
int					ra(t_list **stack_a);
int					rb(t_list **stack_b);
int					rr(t_list **stack_a, t_list **stack_b);

// Push Operations
int					push(t_list **stack_next, t_list **stack_back);
int					pa(t_list **stack_a, t_list **stack_b);
int					pb(t_list **stack_a, t_list **stack_b);

// Swap Operations
int					sa(t_list **stack_a);
int					sb(t_list **stack_b);
int					ss(t_list **stack_a, t_list **stack_b);

// Comands sort
void				radix_sort(t_list **stack_a, t_list **stack_b);
void				sort_3(t_list **stack_a);
void				sort_4(t_list **stack_a, t_list **stack_b);
void				sort_5(t_list **stack_a, t_list **stack_b);
void				simple_sort(t_list **stack_a, t_list **stack_b);
void				sort_132(t_list **stack_a);
void				sort_231(t_list **stack_a, t_list *head, int min);
void				sort_312(t_list **stack_a, t_list *head, int min);

// Utilities
int					id_mov_head(t_list **stack, int id);
// int		index_distance_head(t_list **stack, int index);
int					get_min_vl(t_list **stack, int value);
// int		get_min(t_list **stack, int val);
void				id_stack(t_list **stack);
// void	index_stack(t_list **stack);

#endif

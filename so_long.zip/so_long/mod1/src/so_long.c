/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcorona- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/06 14:20:38 by fcorona-          #+#    #+#             */
/*   Updated: 2025/02/06 14:20:39 by fcorona-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/so_long.h"

void	ft_struct_init(t_game_instance	*game_init)
{
	t_game_objects	*objs;

	*game_init = (t_game_instance){0};
	game_init->map_init.matriz = NULL;
	game_init->mlx_ptr = NULL;
	game_init->win_ptr = NULL;
	game_init->resolutions_init.set_name_map = NULL;
	game_init->resolutions_init.set_name_windows = NULL;
	objs = malloc(sizeof(t_game_objects));
	if (objs == NULL)
		ft_map_fail(12);
	game_init->game_objs = *objs;
	free (objs);
	return ;
}

int	main(int ac, char **av)
{
	t_game_instance	game_init;

	ft_struct_init(&game_init);
	if (ac != 2)
		ft_map_fail(22);
	game_init.ac_tmp = ac;
	game_init.av_tmp = av;
	if (ft_load_map(av[1], &game_init))
	{
		ft_init_game(&game_init);
		ft_start_game(&game_init);
		mlx_loop(game_init.mlx_ptr);
	}
	else
		ft_map_fail(61);
	ft_close_game(&game_init);
	return (0);
}

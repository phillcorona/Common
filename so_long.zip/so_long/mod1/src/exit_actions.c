/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   exit_actions.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcorona- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/07 18:16:35 by fcorona-          #+#    #+#             */
/*   Updated: 2025/02/07 18:38:00 by fcorona-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/so_long.h"

int	ft_close_game(t_game_instance *game_init)
{
	ft_printf("Thank you for playing!! Bye\n");
	ft_img_free(game_init);
	ft_map_free(game_init);
	ft_clear_resources(game_init);
	mlx_destroy_window(game_init->mlx_ptr, game_init->win_ptr);
	mlx_destroy_display(game_init->mlx_ptr);
	free(game_init->mlx_ptr);
	exit(0);
	return (0);
}

void	ft_reload_game(t_game_instance *game_init)
{
	ft_printf("\n Wait a moment!! The game reload!!\n");
	ft_img_free(game_init);
	ft_map_free(game_init);
	if (game_init->resolutions_init.set_name_windows)
		free(game_init->resolutions_init.set_name_windows);
	if (game_init->resolutions_init.set_name_map)
		free(game_init->resolutions_init.set_name_map);
	if (game_init->win_ptr)
		mlx_destroy_window(game_init->mlx_ptr, game_init->win_ptr);
	if (game_init->mlx_ptr)
	{
		mlx_destroy_display(game_init->mlx_ptr);
		free(game_init->mlx_ptr);
	}
	ft_struct_init(game_init);
	if (ft_load_map(game_init->av_tmp[1], game_init))
	{
		ft_init_game(game_init);
		ft_start_game(game_init);
		mlx_loop(game_init->mlx_ptr);
	}
	else
		ft_map_fail(61);
}

void	ft_clear_resources(t_game_instance *game_init)
{
	if (game_init->resolutions_init.set_name_windows != NULL)
	{
		free(game_init->resolutions_init.set_name_windows);
		game_init->resolutions_init.set_name_windows = NULL;
	}
	if (game_init->resolutions_init.set_name_map != NULL)
	{
		free(game_init->resolutions_init.set_name_map);
		game_init->resolutions_init.set_name_map = NULL;
	}
}

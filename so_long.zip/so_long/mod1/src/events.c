/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   events.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcorona- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/07 10:19:06 by fcorona-          #+#    #+#             */
/*   Updated: 2025/02/07 11:08:01 by fcorona-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/so_long.h"

void	ft_start_game(t_game_instance *game_init)
{
	mlx_hook(game_init->win_ptr, 17, 0, ft_close_game, game_init);
	mlx_hook(game_init->win_ptr, 2, (1L << 0), ft_keyboard_action, game_init);
	mlx_loop_hook(game_init->mlx_ptr, &ft_render_map, game_init);
}

int	ft_display_moves(t_game_instance *game_init)
{
	static int	previous_count_mov;
	int			current_count_mov;

	previous_count_mov = -1;
	current_count_mov = game_init->game_data.mov_count;
	if (current_count_mov != previous_count_mov)
	{
		ft_printf("You moved %d times.\n", current_count_mov);
		previous_count_mov = current_count_mov;
	}
	return (1);
}

void	ft_track_player(t_game_instance *game_init)
{
	int	col;
	int	ln;

	ln = 0;
	while (game_init->map_init.matriz[ln] != NULL)
	{
		col = 0;
		while (game_init->map_init.matriz[ln][col] != '\0')
		{
			if (game_init->map_init.matriz[ln][col] == PLAYER)
			{
				game_init->positions_init.player_line = ln;
				game_init->positions_init.player_col = col;
				return ;
			}
			col++;
		}
		ln++;
	}
}

int	ft_player_action(t_game_instance *game_init, int col, int line)
{
	int	new_line;
	int	new_col;
	int	current_tile;

	ft_track_player(game_init);
	new_line = game_init->positions_init.player_line + line;
	new_col = game_init->positions_init.player_col + col;
	current_tile = game_init->map_init.matriz[new_line][new_col];
	if (current_tile == EMPTY || current_tile == COLLECTIBLE)
	{
		game_init->map_init.matriz[new_line][new_col] = PLAYER;
		game_init->map_init.matriz[game_init->positions_init.player_line]
		[game_init->positions_init.player_col] = EMPTY;
		game_init->positions_init.player_line = new_line;
		game_init->positions_init.player_col = new_col;
		if (current_tile == COLLECTIBLE)
			game_init->game_data.collectible_count--;
		game_init->game_data.mov_count++;
	}
	else if (current_tile == EXIT
		&& game_init->game_data.collectible_count == 0)
		ft_victory(game_init);
	return (ft_display_moves(game_init));
}

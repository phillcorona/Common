/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   game_start.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcorona- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/06 15:04:00 by fcorona-          #+#    #+#             */
/*   Updated: 2025/02/06 15:38:51 by fcorona-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/so_long.h"

void	ft_init_game(t_game_instance *game_init)
{
	game_init->mlx_ptr = mlx_init();
	if (game_init->mlx_ptr == NULL)
		ft_init_fail(38);
	game_init->game_data.mov_count = 0;
	ft_load_imgs(game_init);
	game_init->game_objs.player = game_init->game_objs.player_up;
	game_init->win_ptr = mlx_new_window(game_init->mlx_ptr,
			game_init->map_init.resolutions.set_map_width
			* CELL_SIZE, game_init->map_init.resolutions.set_map_height
			* CELL_SIZE, "Wood Search");
	if (game_init->win_ptr == NULL)
		ft_init_fail(38);
}

void	ft_load_imgs(t_game_instance *game_init)
{
	ft_test_imgs(game_init, &game_init->game_objs.player_right,
		"assets/textures/Player/person_right.xpm");
	ft_test_imgs(game_init, &game_init->game_objs.player_up,
		"assets/textures/Player/person_up.xpm");
	ft_test_imgs(game_init, &game_init->game_objs.player_down,
		"assets/textures/Player/person_down.xpm");
	ft_test_imgs(game_init, &game_init->game_objs.player_left,
		"assets/textures/Player/person_left.xpm");
	ft_test_imgs(game_init, &game_init->game_objs.collectible,
		"assets/textures/Collectibles/wood.xpm");
	ft_test_imgs(game_init, &game_init->game_objs.floor,
		"assets/textures/Tiles/floor.xpm");
	ft_test_imgs(game_init, &game_init->game_objs.exit_open,
		"assets/textures/Exit/exit_open.xpm");
	ft_test_imgs(game_init, &game_init->game_objs.exit_close,
		"assets/textures/Exit/exit_close.xpm");
	ft_test_imgs(game_init, &game_init->game_objs.wall,
		"assets/textures/Tiles/tree.xpm");
}

void	ft_test_imgs(t_game_instance *game_init, void **image, char *path)
{
	int	wdth;
	int	hght;

	*image = mlx_xpm_file_to_image(game_init->mlx_ptr, path, &wdth, &hght);
	if (*image == NULL)
	{
		printf("Error: Load image: %s\n", path);
		ft_init_fail(1);
		ft_close_game(game_init);
	}
}

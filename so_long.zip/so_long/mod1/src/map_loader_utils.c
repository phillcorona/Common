/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map_loader_utils.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcorona- <fcorona-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/10 10:06:55 by fcorona-          #+#    #+#             */
/*   Updated: 2025/02/14 10:17:01 by fcorona-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/so_long.h"

int	get_rows_count(t_game_instance *game_init)
{
	int		ln_id;
	int		ln_lng;	

	ln_id = 0;
	while (game_init->map_init.matriz[ln_id])
	{
		ln_lng = ft_strlen(game_init->map_init.matriz[ln_id])
			- (game_init->map_init.matriz[ln_id]
			[ft_strlen(game_init->map_init.matriz[ln_id]) - 1] == '\n');
		if (ln_lng != game_init->map_init.col_matriz)
		{
			game_init->map_init.lines_matriz = 0;
			return (0);
		}
		game_init->map_init.lines_matriz++;
		ln_id++;
	}
	game_init->map_init.size_matriz = game_init->map_init.lines_matriz
		* game_init->map_init.col_matriz;
	game_init->map_init.resolutions.set_map_width
		= game_init->map_init.col_matriz;
	game_init->map_init.resolutions.set_map_height
		= game_init->map_init.lines_matriz;
	return (1);
}

int	get_cols_count(t_map_data *map_init)
{
	char	*ln;
	int		col_num;

	ln = map_init->matriz[0];
	col_num = 0;
	while (*ln && *ln != '\n')
	{
		col_num++;
		ln++;
	}
	return (col_num);
}

int	ft_get_map_size(t_game_instance *game_init)
{
	game_init->map_init.col_matriz = get_cols_count(&game_init->map_init);
	if (game_init->map_init.col_matriz == 0)
		return (0);
	return (get_rows_count(game_init));
}

int	ft_check_map_extension(char *map)
{
	char		*ext;
	char		*name_ext;
	static int	file_lng;

	if (!map || !*map)
		return (0);
	file_lng = 0;
	ext = ".ber";
	name_ext = ft_strrchr(map, '.');
	if (!name_ext)
		return (0);
	if (map[ft_strlen(map) - 1] == '/')
	{
		ft_map_fail(21);
		return (0);
	}
	if (ft_strcmp(name_ext, ext))
		return (0);
	return (1);
}

char	**ft_duplicate_map(char **map)
{
	int		i;
	int		rows;
	char	**copy;

	rows = 0;
	while (map[rows])
		rows++;
	copy = (char **)malloc((rows + 1) * sizeof(char *));
	if (!copy)
		return (NULL);
	i = -1;
	while (++i < rows)
		copy[i] = ft_strdup(map[i]);
	copy[i] = NULL;
	return (copy);
}

int	ft_flood_fill(char **map, int x, int y, t_flood_fill *flood_fill)
{
	if (x < 0 || y < 0 || !map[y] || map[y][x] == '1' || map[y][x] == '\0')
		return (0);
	if (map[y][x] == 'C')
		flood_fill->collectibles--;
	if (map[y][x] == 'E')
	{
		flood_fill->exit_found = 1;
		if (!flood_fill->collectibles)
			return (1);
		return (0);
	}
	map[y][x] = '1';
	if (!flood_fill->collectibles && flood_fill->exit_found)
		return (1);
	if (ft_flood_fill(map, x + 1, y, flood_fill)
		|| ft_flood_fill(map, x - 1, y, flood_fill)
		|| ft_flood_fill(map, x, y + 1, flood_fill)
		|| ft_flood_fill(map, x, y - 1, flood_fill))
		return (1);
	return (0);
}

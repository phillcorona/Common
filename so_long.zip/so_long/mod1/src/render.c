/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   render.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcorona- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/10 11:44:46 by fcorona-          #+#    #+#             */
/*   Updated: 2025/02/10 12:09:05 by fcorona-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/so_long.h"

void	ft_put_img(t_game_instance *game_init, void *img, int width, int height)
{
	mlx_put_image_to_window(game_init->mlx_ptr, game_init->win_ptr,
		img, width * CELL_SIZE, height * CELL_SIZE);
}

int	ft_render_map(t_game_instance *game_init)
{
	int	ln;
	int	col;

	ln = -1;
	while (game_init->map_init.matriz[++ln])
	{
		col = 0;
		while (game_init->map_init.matriz[ln][col])
		{
			if (game_init->map_init.matriz[ln][col] == WALL)
				ft_put_img(game_init, game_init->game_objs.wall, col, ln);
			if (game_init->map_init.matriz[ln][col] == EMPTY)
				ft_put_img(game_init, game_init->game_objs.floor, col, ln);
			if (game_init->map_init.matriz[ln][col] == PLAYER)
				ft_put_img(game_init, game_init->game_objs.player, col, ln);
			if (game_init->map_init.matriz[ln][col] == EXIT)
				ft_render_exit(game_init, col, ln);
			if (game_init->map_init.matriz[ln][col] == COLLECTIBLE)
				ft_put_img(game_init, game_init->game_objs.collectible,
					col, ln);
			col++;
		}
	}
	return (0);
}

void	ft_render_exit(t_game_instance *game_init, int col, int ln)
{
	if (game_init->map_init.matriz[ln][col] == EXIT
		&& game_init->game_data.collectible_count == 0)
		ft_put_img(game_init, game_init->game_objs.exit_open, col, ln);
	else
		ft_put_img(game_init, game_init->game_objs.exit_close, col, ln);
	return ;
}

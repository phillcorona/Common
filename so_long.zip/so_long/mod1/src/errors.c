/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   errors.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcorona- <fcorona-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/06 15:43:49 by fcorona-          #+#    #+#             */
/*   Updated: 2025/02/12 18:21:18 by fcorona-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/so_long.h"

void	ft_init_fail(int n)
{
	if (n == 38)
		ft_printf("Error\n%s",
			"Unable to initialize due to library mismatch!\n");
	else if (n == 1)
		ft_printf("Error\n%s",
			"The operation cannot be performed!\n");
	else if (n == 2)
		ft_printf("Error\n%s",
			"Target file or directory does not exist!\n");
	exit(n);
}

void	ft_map_fail(int n)
{
	if (n == 21)
		ft_printf("Error\n%s",
			"A directory was provided instead of a map file.\n");
	else if (n == 22 || n == 52 || n == 59 || n == 24 || n == 5)
		ft_printf("Error\n%s",
			"The correct format is: ./so_long <path><filename>.ber\n");
	else if (n == 61)
		ft_printf("Error\n%s",
			"The provided map is not valid. Please check and try again.\n");
	else if (n == 10)
		ft_printf("Error\n%s",
			"The provided map is not valid. Collectible is not acessible.\n");
	exit(n);
}

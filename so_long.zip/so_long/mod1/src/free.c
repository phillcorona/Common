/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   free.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcorona- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/07 12:11:48 by fcorona-          #+#    #+#             */
/*   Updated: 2025/02/14 10:12:18 by fcorona-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/so_long.h"

void	ft_map_free(t_game_instance *game_init)
{
	int	i;

	if (game_init->map_init.matriz == NULL)
		return ;
	i = 0;
	while (game_init->map_init.matriz[i])
	{
		free(game_init->map_init.matriz[i]);
		i++;
	}
	free(game_init->map_init.matriz);
	game_init->map_init.matriz = NULL;
	return ;
}

void	ft_img_free(t_game_instance *game_init)
{
	mlx_destroy_image(game_init->mlx_ptr, game_init->game_objs.player_up);
	mlx_destroy_image(game_init->mlx_ptr, game_init->game_objs.player_down);
	mlx_destroy_image(game_init->mlx_ptr, game_init->game_objs.player_left);
	mlx_destroy_image(game_init->mlx_ptr, game_init->game_objs.player_right);
	mlx_destroy_image(game_init->mlx_ptr, game_init->game_objs.collectible);
	mlx_destroy_image(game_init->mlx_ptr, game_init->game_objs.exit_open);
	mlx_destroy_image(game_init->mlx_ptr, game_init->game_objs.exit_close);
	mlx_destroy_image(game_init->mlx_ptr, game_init->game_objs.wall);
	mlx_destroy_image(game_init->mlx_ptr, game_init->game_objs.floor);
	game_init->game_objs = (t_game_objects){0};
}

void	ft_free_matrix(void **matrix, int index)
{
	while (index >= 0)
		free(matrix[index--]);
	free(matrix);
	matrix = NULL;
}

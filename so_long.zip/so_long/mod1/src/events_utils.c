/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   events_utils.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcorona- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/07 11:14:36 by fcorona-          #+#    #+#             */
/*   Updated: 2025/02/07 11:52:13 by fcorona-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/so_long.h"
#include "../lib/libft/includes/libft.h"

int	ft_keyboard_action(int key, t_game_instance *game_init)
{
	ft_control_keys_exit(key, game_init);
	if (key == UP || key == W)
	{
		game_init->game_objs.player = game_init->game_objs.player_up;
		ft_player_action(game_init, 0, -1);
	}
	else if (key == DOWN || key == S)
	{
		game_init->game_objs.player = game_init->game_objs.player_down;
		ft_player_action(game_init, 0, +1);
	}
	else if (key == LEFT || key == A)
	{
		game_init->game_objs.player = game_init->game_objs.player_left;
		ft_player_action(game_init, -1, 0);
	}
	else if (key == RIGHT || key == D)
	{
		game_init->game_objs.player = game_init->game_objs.player_right;
		ft_player_action(game_init, +1, 0);
	}
	return (0);
}

int	ft_control_keys_exit(int key, t_game_instance *game_init)
{
	if (key == ESC)
	{
		ft_printf("\n Thanks por playing the game\n");
		ft_close_game(game_init);
	}
	else if (key == RESTART)
		ft_reload_game(game_init);
	return (0);
}

void	ft_victory(t_game_instance *game_init)
{
	game_init->map_init.matriz[game_init->positions_init.player_line]
	[game_init->positions_init.player_col] = EMPTY;
	game_init->game_data.mov_count++;
	ft_printf("\n Congrats! You colleted all itens in the game. \n");
	ft_close_game(game_init);
}

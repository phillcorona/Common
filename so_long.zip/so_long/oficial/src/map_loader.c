/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map_loader.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcorona- <fcorona-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/07 15:57:47 by fcorona-          #+#    #+#             */
/*   Updated: 2025/02/14 10:19:04 by fcorona-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/so_long.h"
#include "../lib/libft/includes/libft.h"

int	ft_load_map(char *map, t_game_instance *game_init)
{
	int	fd;

	if (!ft_check_map_extension(map))
		return (ft_map_fail(22), 0);
	if (!ft_calculate_map_lines(map))
		return (0);
	fd = open(map, O_RDONLY);
	if (fd == -1)
		return (0);
	game_init->map_init.first_read_matriz = ft_calculate_map_lines(map);
	if (!game_init->map_init.first_read_matriz
		|| game_init->map_init.first_read_matriz < 3)
	{
		close (fd);
		ft_map_free(game_init);
		return (0);
	}
	if (!ft_parse_map(fd, game_init))
	{
		close (fd);
		ft_map_free(game_init);
		return (0);
	}
	close (fd);
	return (1);
}

int	ft_calculate_map_lines(char *map)
{
	int	fd;
	int	count;

	count = 0;
	fd = open(map, O_RDONLY);
	if (fd == -1)
		return (0);
	count = ft_line_counter(fd);
	if (close(fd) == -1)
		return (0);
	return (count);
}

int	ft_line_counter(int fd)
{
	int		count;
	int		i;
	char	buffer[BUFFER_SIZE];
	ssize_t	l_read;

	count = 0;
	while (1)
	{
		l_read = read(fd, buffer, BUFFER_SIZE);
		if (l_read < 0)
			return (0);
		if (l_read == 0)
			break ;
		i = 0;
		while (i < l_read)
		{
			if (buffer[i] == '\n')
				count++;
			i++;
		}
	}
	count++;
	return (count);
}

int	ft_parse_map(int fd, t_game_instance *game_init)
{
	int		i;
	char	*buffer;

	game_init->map_init.matriz
		= ft_calloc(game_init->map_init.first_read_matriz + 1, sizeof(char *));
	if (!game_init->map_init.matriz)
	{
		ft_map_free(game_init);
		return (0);
	}
	i = 0;
	buffer = NULL;
	while (1)
	{
		buffer = get_next_line(fd);
		if (!buffer)
			break ;
		game_init->map_init.matriz[i] = buffer;
		i++;
	}
	if (!ft_verify_map(game_init))
		return (0);
	return (1);
}

int	ft_verify_map(t_game_instance *game_init)
{
	int				map_check_valid;
	char			**map_dup;
	t_flood_fill	flood_fill;

	if (game_init->map_init.matriz[0] == NULL
		|| !ft_get_map_size(game_init) || !ft_map_validator(game_init))
	{
		ft_map_free(game_init);
		return (0);
	}
	map_dup = ft_duplicate_map(game_init->map_init.matriz);
	if (!map_dup)
		ft_map_free(game_init);
	flood_fill.collectibles = game_init->game_data.collectible_count;
	flood_fill.exit_found = 0;
	ft_track_player(game_init);
	map_check_valid = ft_flood_fill(map_dup,
			game_init->positions_init.player_line,
			game_init->positions_init.player_col, &flood_fill);
	ft_free_matrix((void **)map_dup,
		game_init->resolutions_init.set_map_height - 1);
	if (!map_check_valid)
	{
		ft_map_free(game_init);
		ft_map_fail(10);
		return (0);
	}
	return (1);
}

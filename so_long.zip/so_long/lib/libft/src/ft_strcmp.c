/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcorona- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/15 15:29:58 by fcorona-          #+#    #+#             */
/*   Updated: 2024/09/15 16:23:40 by fcorona-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/libft.h"

int	ft_strcmp(const char *s1, const char *s2)
{
	int	i;

	i = 0;
	while ((s1[i] == s2[i]) && (s1[i] != 0) && (s2[i] != 0))
		i++;
	return ((unsigned char)s1[i] - (unsigned char)s2[i]);
}

/*
int	main()
{
        char str1[] = "cadeado1";
        char str2[] = "cadeado2";

        int resultado = ft_strcmp(str1, str2);

        if (resultado < 0)
        {
             printf("The string '%s' is going first than '%s'.\n", str1, str2);
        }
        else if (resultado > 0)
        {
                printf("The string '%s' going first than '%s'.\n", str2, str1);
        }
        else
        {
                printf("The strings is egual.\n");
        }
}*/

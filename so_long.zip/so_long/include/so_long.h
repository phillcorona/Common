/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcorona- <fcorona-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/04 17:54:55 by fcorona-          #+#    #+#             */
/*   Updated: 2025/02/12 19:17:19 by fcorona-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SO_LONG_H
# define SO_LONG_H

# include "../lib/minilibx/mlx.h"
# include "../lib/libft/includes/libft.h"
# include "../lib/libft/includes/ft_printf.h"

# include <fcntl.h>
# include <stdio.h>
# include <unistd.h>
# include <stdlib.h>
# include <string.h> // Strerror

// KEYS
# define PLAYER 'P'
# define EXIT 'E'
# define COLLECTIBLE 'C'
# define WALL '1'
# define EMPTY '0'

// MOVE KEY
# define ESC 65307
# define W 119
# define UP 65362
# define A 97
# define LEFT 65361
# define S 115
# define DOWN 65364
# define D 100
# define RIGHT 65363
# define RESTART 114

# define BUFFER_SIZE 1024
# define MAX_FILES 1

# define TRUE 1
# define FALSE 0

# define CELL_SIZE 64

//Images struct
typedef struct s_game_objects
{
	void	*player;
	void	*player_left;
	void	*player_right;
	void	*player_down;
	void	*player_up;
	void	*collectible;
	void	*exit_open;
	void	*exit_close;
	void	*wall;
	void	*floor;
	int		image_width;
	int		image_height;
}	t_game_objects;

// Movimets of player and exit
typedef struct s_game_positions
{
	int	player_line;
	int	player_col;
	int	exit_line;
	int	exit_col;
}	t_game_positions;

// Data of control the objects inside the game
typedef struct s_game_data
{
	int	player_count;
	int	exit_count;
	int	collectible_count;
	int	wall_count;
	int	empty_count;
	int	mov_count;
	int	endgame;
}	t_game_data;

// Game resolutions 
typedef struct s_game_resolutions
{
	int		set_map_width;
	int		set_map_height;
	char	*set_name_windows;
	char	*set_name_map;
}	t_game_resolutions;

// Game data external the game
typedef struct s_map_data
{
	int					first_read_matriz;
	int					col_matriz;
	int					lines_matriz;
	int					size_matriz;
	char				**matriz;
	t_game_resolutions	resolutions;
	t_game_positions	positions;
}	t_map_data;

// Game controller
typedef struct s_game_instance
{
	void				*mlx_ptr;
	void				*win_ptr;
	int					ac_tmp;
	char				**av_tmp;
	t_map_data			map_init;
	t_game_positions	positions_init;
	t_game_data			game_data;
	t_game_resolutions	resolutions_init;
	t_game_objects		game_objs;
}		t_game_instance;

typedef struct s_flood_fill
{
	int			collectibles;
	int			exit_found;
}				t_flood_fill;

// Game functions
void		ft_struct_init(t_game_instance *game_init);
void		ft_init_game(t_game_instance *game_init);

// Event of flags and moviments
int			ft_keyboard_action(int key, t_game_instance *game_init);
int			ft_control_keys_exit(int key, t_game_instance *game_init);
int			ft_close_game(t_game_instance *game_init);
void		ft_reload_game(t_game_instance *game_init);

// Map validation and flags
int			ft_load_map(char *map, t_game_instance *game_init);
int			ft_calculate_map_lines(char *map);
int			ft_line_counter(int fd);
int			ft_get_map_size(t_game_instance *game_init);
int			get_rows_count(t_game_instance *game_init);
int			get_cols_count(t_map_data *map_init);
int			ft_parse_map(int fd, t_game_instance *game_init);
int			ft_verify_map(t_game_instance *game_init);
int			ft_check_map_extension(char *map);
int			ft_map_validator(t_game_instance *game_init);
int			ft_check_map_shape(t_game_instance *game_init);
int			ft_check_wall(t_game_instance *game_init);
int			ft_object_counter(t_game_instance *game_init);
int			ft_check_map_needs(t_game_instance *game_init);
int			ft_check_col(t_game_instance *game_init);
char		**ft_duplicate_map(char **map);
int			ft_flood_fill(char **map, int x, int y, t_flood_fill *flood_fill);

// Map validation and data control
void		ft_start_game(t_game_instance *game_init);
int			ft_player_action(t_game_instance *game_initm, int clmn, int line);
void		ft_victory(t_game_instance *game_init);
int			ft_display_moves(t_game_instance *game_init);
void		ft_track_player(t_game_instance *game_init);
void		ft_load_imgs(t_game_instance *game_init);
void		ft_test_imgs(t_game_instance *game_init, void **image, char *path);
int			ft_render_map(t_game_instance *game_init);
void		ft_render_exit(t_game_instance *game_init, int clmn, int line);
void		ft_put_img(t_game_instance *game_init, void *img, int wid, int hgt);

// Free all memory
void		ft_map_free(t_game_instance *game_init);
void		ft_img_free(t_game_instance *game_init);
void		ft_clear_resources(t_game_instance *game_init);
void		ft_free_matrix(void **matrix, int index);

// Error control
void		ft_init_fail(int n);
void		ft_map_fail(int n);

// Auxiliary
//int			ft_strcmp(const char *s1, const char *s2);
//--- colocada na libft
#endif
